import React from 'react';
import Stock from './Stock';
import './App.css';

function App() {
  return (
    <div className="App">
      <Stock></Stock>
    </div>
  );
}

export default App;
