export interface IFormatter {
	// eslint-disable-next-line @typescript-eslint/no-explicit-any
	format(value: any): string;
}
