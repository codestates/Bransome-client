module.exports = {
	env: {
		node: true,
	},
	rules: {
		'no-console': [
			'off',
		],
	},
};
