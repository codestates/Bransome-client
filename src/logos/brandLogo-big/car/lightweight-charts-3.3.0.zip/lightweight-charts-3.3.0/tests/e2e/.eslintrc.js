module.exports = {
	rules: {
		'no-console': [
			'off',
		],
	},
};
